#install.packages("C50")
#install.packages("gmodels")

library(C50)
library(gmodels)

## Reading the dataset into the R studio from the computer
immuno = read.csv("Q:/Desktop/Module/Data Science/RProgrammingCode/data/Immunotherapy.csv", stringsAsFactors = FALSE)

## This displays the first several rows of the data
head(immuno)

## This displays the structure of the variables
str(immuno)

## The dataset is attached to the R search path
attach(immuno)
##recode sex to a factor from int
immuno$sex <- as.factor(immuno$sex)
immuno$sex <- factor (immuno$sex, levels = c("1","2"), labels = c("Male", "Female"))
immuno$sex

## recode wart type to a factor from int
immuno$Type <- as.factor(immuno$Type)
immuno$Type <- factor (immuno$Type, levels = c("1","2", "3"), labels = c("Plantar", "Common", "Both"))
immuno$Type

##recode Result_of_Treatment type as a factor
immuno$Result_of_Treatment <- as.factor(immuno$Result_of_Treatment)
immuno$Result_of_Treatment <- factor (immuno$Result_of_Treatment, levels = c("0","1"), labels = c("Yes", "No"))
immuno$Result_of_Treatment

## Setting the seed
set.seed(42)

## Perform random operation on the data set
immuno_rand <- immuno[order(runif(90)), ]

## compare result of immuno$Age and immuno_rand$Age

summary(immuno$sex)
summary(immuno_rand$sex)

head(immuno$sex)
head(immuno_rand$sex)


## Splitting the random number into train and test data of 80% to 20% respectively.
splitdata <- sample(1:nrow(immuno_rand),0.8*nrow(immuno_rand))

# The training data
immuno_train <- immuno_rand[splitdata, ]
dim(immuno_train) 

## The test data
immuno_test <- immuno_rand[-splitdata, ]
dim(immuno_test)

## Perform the model on the train data using the output
immuno_model <- C5.0(Result_of_Treatment ~., data = immuno_train)

## Summary of model
summary(immuno_model)

## Plot the graph
plot(immuno_model)

## Making prediction using the test data
immuno_predict = predict(immuno_model, immuno_test)

## Cross Table
CrossTable(immuno_predict, immuno_test$Result_of_Treatment,prop.chisq = FALSE, prop.c = TRUE, prop.r = TRUE,
           dnn = c('actual value', 'predicted value'))





