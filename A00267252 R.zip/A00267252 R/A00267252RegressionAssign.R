
## Reading the dataset into the R studio from the computer
carbonnanotubes = read.csv("Q:/Desktop/Module/Data Science/RProgrammingCode/data/carbon_nanotubes.csv")

## This displays the first several rows of the data
head(carbonnanotubes)

## This displays the structure of the variables 
str(carbonnanotubes)
names(carbonnanotubes) ## Display the attributes of the dataset

## The dataset is attached to the R search path
attach(carbonnanotubes)

#checking if there is relationship or correlation between our predictor and response
cor(Initial_atomic_coordinate_w,Calculated_atomic_coordinates_w)

#Plot the graph of between the predictor and response with a high correlation
plot(Initial_atomic_coordinate_w,Calculated_atomic_coordinates_w, main = "Graph of Calculate atomic cordinate against the initial atomic cordinate of w", col=c("green", "blue"))

## Creating simulations or random objects that can be reproduced.
set.seed(42)

## Perform the random operation on the set data
carbonnanotubes_rand <- carbonnanotubes[order(runif(10721)), ]

## Splitting the train & test data from the Carbon Nanotube datasetin a 80% 20% proportion

splitdata <- sample(1:nrow(carbonnanotubes_rand),0.8*nrow(carbonnanotubes_rand))
##splitdata1 <- sort(sample(nrow(carbonnanotubes_rand), 0.8*nrow(carbonnanotubes_rand)))

## Getting the train data from the splitdata
carbonnanotubes_train <- carbonnanotubes_rand[splitdata, ]
dim(carbonnanotubes_train) ## This shows the total dataset in carbonnanotubes_train

## Setting the test data from the Carbon Nanotube dataset
carbonnanotubes_test <- carbonnanotubes_rand[-splitdata, ]
dim(carbonnanotubes_test) ## This shows the total dataset in carbonnanotubes_test

## Performing the regression model base on the train dataset 
lm_carbonnanotubes  <- lm(Calculated_atomic_coordinates_w ~ Initial_atomic_coordinate_w, data = carbonnanotubes_train)

## Drawing theline of the regression model
abline(lm_carbonnanotubes, col=c("red"), lwd=2)

## Displaying the result summaries of the regression model
summary(lm_carbonnanotubes)

## Predicting the test data using the predicted / regression model
prediction <- predict(lm_carbonnanotubes, newdata = carbonnanotubes_test)
##head(prediction)
prediction
head(prediction) #This shows few of the predicted data set
head(carbonnanotubes_test$Calculated_atomic_coordinates_w) # This shows few of the actual dataset

##Calculating the root mean squared error (RMSE)for the train data
trainError <- residuals(lm_carbonnanotubes)
squareTrainError <- trainError^2
meanSquareTrainError <- mean(squareTrainError)
meanSquareTrainError
trainRMSE <- sqrt(meanSquareTrainError)
trainRMSE




