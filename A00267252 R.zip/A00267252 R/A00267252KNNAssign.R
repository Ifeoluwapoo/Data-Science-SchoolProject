#install.packages("C50")
#install.packages("gmodels")

library(C50)
library(gmodels)

## Reading the dataset into the R studio from the computer
immuno = read.csv("Q:/Desktop/Module/Data Science/RProgrammingCode/data/Immunotherapy.csv", stringsAsFactors = FALSE)

## This displays the first several rows of the data
head(immuno)

## This displays the structure of the variables
str(immuno)

## The dataset is attached to the R search path
attach(immuno)

##recode Result_of_Treatment type as a factor
immuno$Result_of_Treatment <- as.factor(immuno$Result_of_Treatment)
immuno$Result_of_Treatment <- factor (immuno$Result_of_Treatment, levels = c("0","1"), labels = c("Yes", "No"))
immuno$Result_of_Treatment

round(prop.table(table(immuno$Result_of_Treatment)) * 100, digits = 1)

## Simple code to perform normalisation
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

set.seed(70)

immuno_n <- as.data.frame(lapply(immuno[1:7], normalize))



# Splitting the dataset into 80% 20%
splitdata <- sample(1:nrow(immuno_n),0.8*nrow(immuno_n))

# The training data
immuno_train <- immuno_n[splitdata, ]
dim(immuno_train) 

## The test data
immuno_test <- immuno_n[-splitdata, ]
dim(immuno_test)


##Splitting the input variables for visualisation

x <- immuno_train[,1:7]

par(mfrow=c(1,7))
for(i in 1:7) {
  boxplot(x[,i], main=names(immuno_train)[i])
  
}


## create labels for training and test data
immuno_train_labels <- immuno[splitdata, 8]
immuno_test_labels <- immuno[-splitdata, 8]

## Step 3: Training a model on the data ----
library(class)
immuno_test_pred <- knn(train = immuno_train, test =
                          immuno_test, cl = immuno_train_labels, k=5)

#immuno_test_pred

## Step 4: Evaluating model performance ----
# Make sure the "gmodels" library is loaded
# Create the cross tabulation of predicted vs. actual


CrossTable(x = immuno_test_labels, y = immuno_test_pred,
           prop.chisq=FALSE)





